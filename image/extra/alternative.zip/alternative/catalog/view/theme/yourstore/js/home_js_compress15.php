<?php
header("Content-type: text/javascript");


// Array of js files
$css = array(
 '../external/modernizr/modernizr.js',
 '../external/jquery/jquery-2.1.4.min.js',
 '../external/bootstrap/bootstrap.min.js',
    '../../../javascript/bootstrap/js/bootstrap_without_dd_carousel.js',

    '../external/bootstrap-select/bootstrap-select.min.js',
    '../external/countdown/jquery.plugin.min.js',
    '../external/countdown/jquery.countdown.min.js',
    '../external/magnific-popup/jquery.magnific-popup.min.js',
    '../external/isotope/isotope.pkgd.min.js',
    '../external/imagesloaded/imagesloaded.pkgd.min.js',
    '../external/colorbox/jquery.colorbox-min.js'


);
include('../common_merge.php');